<?php
/**
 *  Avatec Inpost Integration
 *  Copyright (c) 2020 Grzegorz Miskiewicz
 *  All Rights Reserved
 */

$_ = [
    'text_title' => 'Paczkomaty inpost',
    'text_description' => 'Inpost',
    'text_select_header' => 'Wybierz paczkomat odbioru',

    'button_close' => 'Zamknij',
    'button_select' => 'Wybierz',
    'button_select_item' => 'wybierz paczkomat'
];
