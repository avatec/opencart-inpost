<?php
/**
 *  Avatec Inpost Integration
 *  Copyright (c) 2020 Grzegorz Miskiewicz
 *  All Rights Reserved
 */

$_ = [
    'text_title' => 'Paczkomaty inpost',
    'text_description' => 'Inpost',

    'button_close' => 'Zamknij',
    'button_select' => 'Wybierz'
];
